package com.mycompany.registrationandlogin;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
public class TestRegistrationAndLogin {
    
@Test
public void TestcheckUserName(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkUserName("kyl_1");
assertTrue(result);
}
@Test
public void TestcheckUserName2(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkUserName("kyle!!!!!!!");
assertFalse(result);
}
@Test
public void TestcheckPassword(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkPassword("ch&&sec@ke99!");
assertTrue(result);
}
@Test
public void TestcheckPassword2(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkPassword("password");
assertFalse(result);
}
@Test
public void TestcheckcellPhoneNumber(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkcellPhoneNumber("+27838968976");
assertTrue(result);
}
@Test
public void TestcheckcellPhoneNumber2(){
TestRegistrationAndLogin system = new TestRegistrationAndLogin();
boolean result = system.checkcellPhoneNumber("08966553");
assertFalse(result);
}

    private boolean checkcellPhoneNumber(String string) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean checkPassword(String password) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private boolean checkUserName(String kyle) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}

//Java Programming Joyce Farrell(2012)
//Shaping the direction of Java Mark Reinhold(2012
// AI(for phone pattern assistance)
//Regex(for pattern testing)










