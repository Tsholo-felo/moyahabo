/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
package com.mycompany.registrationandlogin;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import org.junit.jupiter.api.Test;
// Test class for the message class
public class TestMessage {


    @Test
    public void testMessageLength_Success() {
        String text = "Hi Mike, can you join us for dinner tonight";
        assertTrue(text.length() <= 250);
    }

    @Test
    public void testMessageLength_Failure() {
        String longText = "A".repeat(260);
        assertFalse(longText.length() <= 250);
    }

    @Test
    public void testRecipientNumber_Valid() {
        String number = "+27718693002";
        assertTrue(number.matches("^\\+27\\d{9}$"));
    }

    @Test
    public void testRecipientNumber_Invalid() {
        String number = "08575975889";
        assertFalse(number.matches("^\\+27\\d{9}$"));
    }

    @Test
    public void testMessageHash_Format() {
        Message msg = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight", 0);
        String expectedStart = msg.getMessageHash().substring(0, 8); // e.g., 00:0:HI
        assertTrue(expectedStart.matches("\\d{2}:\\d:.*"));
    }
}

//Java Programming Joyce Farrell(2012)
//Shaping the direction of Java Mark Reinhold(2012)
// AI(for phone pattern assistance)
//Regex(for pattern testing)


