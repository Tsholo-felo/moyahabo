/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registrationandlogin;

import javax.swing.*;
import java.util.*;
import java.io.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


public class QuickChat {
//lists to store sent and stored messages
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static int totalMessagesSent = 0; // COUNTER FOR TOTAL MESSAGES SENT
    

    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");// Display welcome message
        // Get the message limit from the user
        int messageLimit = Integer.parseInt(JOptionPane.showInputDialog("How many messages would you like to enter?"));
        // Run the application loop
        while (true) { // Display menu opyions to the user
            String menu = "1) Send Message\n2) Show Recently Sent Messages\n3) Quit";
            int choice = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (choice) { //Handle user input
                case 1: // Check if the message limit has been reached
                    if (totalMessagesSent >= messageLimit) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.");
                        break; // Create a new message objects
                    }

                    Message msg = createMessage(totalMessagesSent);
                    // Validate the recipient's phone number
                    if (!msg.checkRecipientCell()) {
                        JOptionPane.showMessageDialog(null, "Invalid phone number. Please include international code (e.g. +27...).");
                        break;
                    }
                    // Validate the message length
                    if (msg.getMessageText().length() > 250) {
                        JOptionPane.showMessageDialog(null, "Message exceeds 250 characters by " +
                                (msg.getMessageText().length() - 250) + ". Please reduce the size.");
                        break;
                    }
                   // Get the user's option for the message (send, store, or discard)
                    String option = msg.sendMessageOption();

                    switch (option) {
                        case "Send":
                            // And the message to the sent messages list and increment the counter
                            sentMessages.add(msg);
                            totalMessagesSent++;
                            JOptionPane.showMessageDialog(null, msg.displayDetails());
                            break;
                        case "Store":
                            // Add the message to the stored messages list and save to JSON
                            storedMessages.add(msg);
                            storeMessagesToJson();
                            JOptionPane.showMessageDialog(null, "Message successfully stored.");
                            break;
                        case "Discard":
                            JOptionPane.showMessageDialog(null, "Message discarded.");
                            break;
                    }
                    break;

                case 2:
                    // Show recently sent messages (not implemented yet)
                    JOptionPane.showMessageDialog(null, "Coming Soon.");
                    break;

                case 3:
                    // Quit the application and display the total messages sent
                    JOptionPane.showMessageDialog(null, "Total Messages Sent: " + totalMessagesSent);
                    System.exit(0);
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Try again.");
            }
        }
    }
        // Creates a new message object based on user input
    private static Message createMessage(int messageNumber) {
        // Get the recipient's phone number and message text from the user 
        String recipient = JOptionPane.showInputDialog("Enter recipient number (e.g., +27718693002):");
        String messageText = JOptionPane.showInputDialog("Enter your message (max 250 characters):");
        return new Message(recipient, messageText, messageNumber);
    }
                // Stores the messages to a JSON file
    private static void storeMessagesToJson() {
        try {
            // Create a Gson object to convert the messages to JSON
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            // Write the messages to a file
            FileWriter writer = new FileWriter("stored_messages.json");
            gson.toJson(storedMessages, writer);
            writer.close();   
        } catch (IOException e) {
            //Display an error message if the file cannot be written
            JOptionPane.showMessageDialog(null, "Failed to store messages: " + e.getMessage());
        }
    }
}
//Java Programming Joyce Farrell(2012)
//Shaping the direction of Java Mark Reinhold(2012)
// AI(for phone pattern assistance)
//Regex(for pattern testing)



