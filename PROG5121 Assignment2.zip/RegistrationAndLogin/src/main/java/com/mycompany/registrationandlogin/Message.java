/* * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registrationandlogin;

import javax.swing.*;
import java.util.Random;

public class Message {
    // Properties of the message
    private String recipient;
    private String messageText;
    private String messageID;
    private int messageNumber;
    private String messageHash;

    // Constructor to create a new message object.
    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
        this.messageID = generateMessageID();
        this.messageHash = createMessageHash();
    }

    // Generate 10-digit random ID
    private String generateMessageID() {
        Random rand = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(rand.nextInt(10));
        }
        return id.toString();
    }

    public boolean checkMessageID() {
        return this.messageID.length() == 10;
    }
    // Checks if the recipient's phone nuber is valid (Starts with + and has 11-13 digits.)
    public boolean checkRecipientCell() {
        return recipient.startsWith("+") && recipient.length() <= 13 && recipient.length() >= 11;
    }
    // Creates a hash code for the message based on its ID, number, and text
    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+"); //Split the text into words 
        String firstWord = words[0]; // First word 
        String lastWord = words[words.length - 1]; // Last word 
        String prefix = messageID.substring(0, 2); // Prefix from the ID
        return (prefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase(); // Combine and convert to uppercase
    }
    // Display options to the user to send, store, or discard the message
    public String sendMessageOption() {
        Object[] options = {"Send", "Store", "Discard"};
        // Options for the user
        int choice = JOptionPane.showOptionDialog(null, "What would you like to do with this message?",
                "Choose Action", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (choice == 0) return "Send";
        else if (choice == 1) return "Store";
        else return "Discard";
    }
    // Display the details of the message
    public String displayDetails() {
        return "Message ID: " + messageID + "\n" +
               "Message Hash: " + messageHash + "\n" +
               "Recipient: " + recipient + "\n" +
               "Message: " + messageText;
    }

    // Getters for JSON storage
    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageID() {
        return messageID;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getMessageHash() {
        return messageHash;
    }
}
//Java Programming Joyce Farrell(2012)
//Shaping the direction of Java Mark Reinhold(2012)
// AI(for phone pattern assistance)
//Regex(for pattern testing)


